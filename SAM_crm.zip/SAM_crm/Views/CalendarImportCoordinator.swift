//
//  CalendarImportCoordinator.swift
//  SAM_crm
//
//  Created by David Snyder on 2/2/26.
//

import Foundation
import EventKit
import SwiftUI

@MainActor
final class CalendarImportCoordinator {

    static let shared = CalendarImportCoordinator()

    private let eventStore = EKEventStore()
    private let evidenceStore = MockEvidenceRuntimeStore.shared

    @AppStorage("sam.calendar.import.enabled") private var importEnabled: Bool = true
    @AppStorage("sam.calendar.selectedCalendarID") private var selectedCalendarID: String = ""
    @AppStorage("sam.calendar.import.windowPastDays") private var pastDays: Int = 60
    @AppStorage("sam.calendar.import.windowFutureDays") private var futureDays: Int = 30
    @AppStorage("sam.calendar.import.lastRunAt") private var lastRunAt: Double = 0

    private var debounceTask: Task<Void, Never>?

    // Normal throttling (launch / app-activate) can be conservative,
    // but calendar-change events should prune quickly.
    private let minimumIntervalNormal: TimeInterval = 300   // 5 minutes
    private let minimumIntervalChanged: TimeInterval = 10    // 10 seconds

    func kick(reason: String) {
        debounceTask?.cancel()

        debounceTask = Task {
            // Debounce bursts of EKEventStoreChanged / app activation.
            try? await Task.sleep(nanoseconds: 1_500_000_000) // 1.5s
            await importIfNeeded(reason: reason)
        }
    }

    func importNow() async {
        await importCalendarEvidence()
    }

    private func importIfNeeded(reason: String) async {
        guard importEnabled else { return }
        guard !selectedCalendarID.isEmpty else { return }

        let now = Date().timeIntervalSince1970
        let minInterval = reason.lowercased().contains("changed")
            ? minimumIntervalChanged
            : minimumIntervalNormal

        guard now - lastRunAt > minInterval else { return }

        await importCalendarEvidence()
    }

    private func importCalendarEvidence() async {
        let status = EKEventStore.authorizationStatus(for: .event)
        // Reading requires full access.
        guard status == .fullAccess else { return }

        guard let calendar = eventStore.calendars(for: .event)
            .first(where: { $0.calendarIdentifier == selectedCalendarID }) else { return }

        let start = Calendar.current.date(byAdding: .day, value: -pastDays, to: Date())!
        let end = Calendar.current.date(byAdding: .day, value: futureDays, to: Date())!

        let predicate = eventStore.predicateForEvents(withStart: start, end: end, calendars: [calendar])
        let events = eventStore.events(matching: predicate)

        // Track what currently exists in the observed calendar for this window.
        let currentUIDs: Set<String> = Set(events.map { "eventkit:\($0.calendarItemIdentifier)" })

        // Prune calendar evidence that no longer exists in the observed calendar (moved/deleted).
        evidenceStore.pruneCalendarEvidenceNotIn(
            currentUIDs,
            windowStart: start,
            windowEnd: end
        )

        for event in events {
            let sourceUID = "eventkit:\(event.calendarItemIdentifier)"

            let item = EvidenceItem(
                id: UUID(),
                state: .needsReview,
                sourceUID: sourceUID,
                source: .calendar,
                occurredAt: event.startDate,
                title: (event.title?.isEmpty == false ? event.title! : "Untitled Event"),
                snippet: event.location ?? event.notes ?? "",
                bodyText: event.notes,
                participantHints: [],
                signals: [],
                proposedLinks: [],
                linkedPeople: [],
                linkedContexts: []
            )

            evidenceStore.upsert(item)
        }

        lastRunAt = Date().timeIntervalSince1970
    }
}
