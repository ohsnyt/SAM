//
//  MockContextRuntimeStore.swift
//  SAM_crm
//
//  Created by David Snyder on 2/1/26.
//

import SwiftUI
import Observation

@MainActor
@Observable
final class MockContextRuntimeStore {
    static let shared = MockContextRuntimeStore()

    private(set) var all: [ContextDetailModel] = MockContextStore.all

    var byID: [UUID: ContextDetailModel] {
        Dictionary(uniqueKeysWithValues: all.map { ($0.id, $0) })
    }

    var listItems: [ContextListItemModel] {
        all.map { ctx in
            ContextListItemModel(
                id: ctx.id,
                name: ctx.name,
                subtitle: ctx.listSubtitle,
                kind: ctx.kind,
                consentCount: ctx.alerts.consentCount,
                reviewCount: ctx.alerts.reviewCount,
                followUpCount: ctx.alerts.followUpCount
            )
        }
    }

    func add(_ draft: NewContextDraft) -> UUID {
        let newID = UUID()

        // Minimal “starter” participant so detail doesn’t look empty
        let starterParticipants: [ContextParticipantModel] = draft.includeDefaultParticipants
        ? [
            ContextParticipantModel(
                id: UUID(),
                displayName: "Primary Person",
                roleBadges: ["Client"],
                icon: "person.crop.circle",
                isPrimary: true,
                note: nil
            )
          ]
        : []

        let created = ContextDetailModel(
            id: newID,
            name: draft.name,
            kind: draft.kind,
            alerts: ContextAlerts(consentCount: 0, reviewCount: 0, followUpCount: 0),
            participants: starterParticipants,
            products: [],
            consentRequirements: [],
            recentInteractions: [],
            insights: []
        )

        all.insert(created, at: 0)
        return newID
    }
}
