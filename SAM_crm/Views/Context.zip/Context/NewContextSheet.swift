//
//  NewContextSheet.swift
//  SAM_crm
//
//  Created by David Snyder on 2/1/26.
//

import SwiftUI

struct NewContextSheet: View {
    @Environment(\.dismiss) private var dismiss

    @State private var name: String = ""
    @State private var kind: ContextKind = .household
    @State private var includeDefaultParticipants: Bool = true

    let onCreate: (NewContextDraft) -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("New Context")
                .font(.title2)
                .bold()

            Form {
                TextField("Name", text: $name)
#if os(iOS)
                    .textInputAutocapitalization(.words)
#endif
                    .onSubmit { create() }

                Picker("Type", selection: $kind) {
                    Text("Household").tag(ContextKind.household)
                    Text("Business").tag(ContextKind.business)
                    Text("Recruiting").tag(ContextKind.recruiting)
                }

                Toggle("Add starter participants", isOn: $includeDefaultParticipants)
                    .help("Creates a minimal set of participants so the detail view doesn’t look empty.")
            }
            .formStyle(.grouped)

            HStack {
                Button("Cancel") { dismiss() }
                    .keyboardShortcut(.cancelAction)

                Spacer()

                Button("Create") { create() }
                    .keyboardShortcut(.defaultAction)
            }
            .padding(.top, 6)
        }
        .padding(18)
        .frame(width: 420)
    }

    private func create() {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        let finalName = trimmed.isEmpty ? defaultName(for: kind) : trimmed

        onCreate(NewContextDraft(
            name: finalName,
            kind: kind,
            includeDefaultParticipants: includeDefaultParticipants
        ))
        dismiss()
    }

    private func defaultName(for kind: ContextKind) -> String {
        switch kind {
        case .household: return "New Household"
        case .business: return "New Business"
        case .recruiting: return "New Recruiting Context"
        }
    }
}

// Draft object: what the sheet produces
struct NewContextDraft {
    let name: String
    let kind: ContextKind
    let includeDefaultParticipants: Bool
}
