//
//  PersonDetailHost.swift
//  SAM_crm
//
//  Created by David Snyder on 1/31/26.
//

import SwiftUI

struct PersonDetailHost: View {
    let selectedPersonID: UUID?
    private let people = MockPeopleData.allPeople

    var body: some View {
        if let id = selectedPersonID,
           let person = people.first(where: { $0.id == id }) {
            PersonDetailView(person: person)
        } else {
            ContentUnavailableView("Select a person",
                                   systemImage: "person.crop.circle",
                                   description: Text("Choose someone from the People list."))
            .padding()
        }
    }
}
